package br.edu.fateczl.aulafateczlspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulafateczlspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulafateczlspringApplication.class, args);
	}

}
