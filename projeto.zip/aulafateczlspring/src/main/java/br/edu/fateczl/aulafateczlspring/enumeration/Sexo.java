package br.edu.fateczl.aulafateczlspring.enumeration;
public enum Sexo {
    M,
    F
}
