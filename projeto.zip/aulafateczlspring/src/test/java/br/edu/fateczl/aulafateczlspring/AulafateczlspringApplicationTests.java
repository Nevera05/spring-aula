package br.edu.fateczl.aulafateczlspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulafateczlspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
